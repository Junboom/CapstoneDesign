//! [0]
OutputType inputToOutputItem(const InputType &inputType) const;
//! [0]
