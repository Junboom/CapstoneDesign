//! [0]
child = QAccessibleInterface()
targetChild = object.navigate(Accessible.Child, 1, child)
if child:
    # ...
    del child
//! [0]
