//! [0]
key = QKeySequence()
//! [0]
