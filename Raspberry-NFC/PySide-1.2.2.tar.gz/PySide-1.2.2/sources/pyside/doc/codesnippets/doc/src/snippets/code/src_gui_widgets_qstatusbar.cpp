//! [0]
statusBar().addWidget(MyReadWriteIndication())
//! [0]
