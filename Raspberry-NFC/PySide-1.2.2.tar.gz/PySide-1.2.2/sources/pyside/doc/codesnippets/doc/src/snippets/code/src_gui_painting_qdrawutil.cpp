//! [0]
frame = QFrame()
frame.setFrameStyle(QFrame.HLine | QFrame.Sunken)
//! [0]


//! [1]
frame = QFrame()
frame.setFrameStyle(QFrame.Box | QFrame.Raised)
//! [1]


//! [2]
frame = QFrame()
frame.setFrameStyle( QFrame.Panel | QFrame.Sunken)
//! [2]


//! [3]
frame = QFrame()
frame.setFrameStyle(QFrame.WinPanel | QFrame.Raised)
//! [3]


//! [4]
frame = QFrame()
frame.setFrameStyle(QFrame.Box | QFrame.Plain)
//! [4]


//! [5]
frame = QFrame()
frame.setFrameStyle(QFrame.HLine | QFrame.Sunken)
//! [5]


//! [6]
frame = QFrame()
frame.setFrameStyle(QFrame.Box | QFrame.Raised)
//! [6]


//! [7]
frame = QFrame()
frame.setFrameStyle( QFrame.Panel | QFrame.Sunken)
//! [7]


//! [8]
frame = QFrame()
frame.setFrameStyle(QFrame.WinPanel | QFrame.Raised)
//! [8]


//! [9]
frame = QFrame()
frame.setFrameStyle(QFrame.Box | QFrame.Plain)
//! [9]
