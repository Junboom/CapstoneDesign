//! [0]
button = QRadioButton("Search from the &cursor", self)
//! [0]
