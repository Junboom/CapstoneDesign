//! [0]
button = QPushButton("&Download", self)
//! [0]
