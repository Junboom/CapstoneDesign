//! [0]
python myapplication.py -style motif
//! [0]


//! [1]
python myapplication.py -style custom
//! [1]
