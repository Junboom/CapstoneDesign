//! [0]
widget = splitter.widget(index)
policy = widget.sizePolicy()
policy.setHorizontalStretch(stretch)
policy.setVerticalStretch(stretch)
widget.setSizePolicy(policy)
//! [0]
