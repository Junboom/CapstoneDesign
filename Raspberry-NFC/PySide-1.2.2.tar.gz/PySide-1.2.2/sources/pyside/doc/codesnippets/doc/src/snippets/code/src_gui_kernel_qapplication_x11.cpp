//! [0]
QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
calculateHugeMandelbrot()              # lunch time...
QApplication.restoreOverrideCursor()
//! [0]
