//! [0]
spinBox = QSpinBox(self)
spinBox.setRange(0, 100)
spinBox.setWrapping(True)
spinBox.setValue(100)
spinBox.stepBy(1)
// value is 0
//! [0]
