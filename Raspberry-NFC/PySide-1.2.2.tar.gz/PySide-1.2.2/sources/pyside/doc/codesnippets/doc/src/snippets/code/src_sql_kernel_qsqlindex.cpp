//! [0]
strlist = myIndex.toStringList()
for i in strlist:
    myProcessing(i)
//! [0]
