//! [0]
r1 = QRect(100, 200, 11, 16)
r2 = QRect(QPoint(100, 200), QSize(11, 16))
//! [0]


//! [1]
r1 = QRectF(100, 200, 11, 16)
r2 = QRectF(QPoint(100, 200), QSize(11, 16))
//! [1]
