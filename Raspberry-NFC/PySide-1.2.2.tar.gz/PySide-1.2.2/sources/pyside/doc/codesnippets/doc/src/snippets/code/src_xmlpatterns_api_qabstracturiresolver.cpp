//! [0]
return baseURI.resolved(relative);
//! [0]
