

//! [0]
extern Q_CORE_EXPORT int qt_ntfs_permission_lookup;
//! [0]

//! [1]
qt_ntfs_permission_lookup += 1 // turn checking on
qt_ntfs_permission_lookup += 1 // turn it off again
//! [1]

