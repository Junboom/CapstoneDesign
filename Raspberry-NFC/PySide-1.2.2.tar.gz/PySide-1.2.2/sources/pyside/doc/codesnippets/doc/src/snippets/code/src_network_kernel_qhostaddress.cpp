//! [0]
addr = hostAddr.toIPv6Address()
# addr contains 16 unsigned characters

for i in range(0, 16):
    # process addr[i]
//! [0]
